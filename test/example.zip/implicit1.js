var ucon_x;
var con_y;

/* VARS */
ucon_x  = (Math.random() < 0.5)
con_y   = (Math.random() < 0.5)
/* MAIN JS PROGRAM */
if (ucon_x){
  con_y = false
}
/// END OF FILE ///
